import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruiter-profil',
  templateUrl: './recruiter-profil.component.html',
  styleUrls: ['./recruiter-profil.component.css']
})
export class RecruiterProfilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
