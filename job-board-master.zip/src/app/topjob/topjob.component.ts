import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topjob',
  templateUrl: './topjob.component.html',
  styleUrls: ['./topjob.component.css']
})
export class TopjobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
