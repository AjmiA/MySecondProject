export interface Candidate {
    id: number;
    name: string;
    birthDate: string;
    education: string;
    experience: number;
    
}
